/*
 * parallel.h
 *
 *  Created on: 16/03/2017
 *      Author: marques999
 */

#ifndef PARALLEL_H_
#define PARALLEL_H_

void RunParallel(int algorithmIndex, const uint64_t maximumValue, int numberThreads);

#endif /* PARALLEL_H_ */
