/*
 * sequential.h
 *
 *  Created on: 16/03/2017
 *      Author: marques999
 */

#ifndef SEQUENTIAL_H_
#define SEQUENTIAL_H_

void RunSequential(int algorithmIndex, const uint64_t maximumValue);

#endif /* SEQUENTIAL_H_ */
